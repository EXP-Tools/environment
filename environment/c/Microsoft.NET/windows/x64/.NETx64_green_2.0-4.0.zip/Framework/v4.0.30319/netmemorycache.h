//  <copyright file="netmemorycache.h" company="Microsoft">
//    Copyright (c) 2009 Microsoft Corporation.  All rights reserved.
//  </copyright>

#define OBJECT_1 0;
#define DEVICE_COUNTER_1 2;
#define DEVICE_COUNTER_2 4;
#define DEVICE_COUNTER_3 6;
#define DEVICE_COUNTER_4 8;
#define DEVICE_COUNTER_5 10;
#define DEVICE_COUNTER_6 12;
#define DEVICE_COUNTER_7 14;

